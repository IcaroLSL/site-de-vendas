import express from 'express';
import cors from 'cors';
import fs from 'fs';

const app = express();
const PORT = 3000;

app.use(cors());  // Habilita o CORS

// Função para aleatorizar a ordem dos produtos
function embaralharArray(array: any[]) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]]; // Troca os elementos
  }
}

// Endpoint para obter produtos
app.get('/api/produtos', (req, res) => {
  fs.readFile('./data.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Erro ao ler o arquivo:', err);
      return res.status(500).send('Erro ao ler os dados');
    }

    try {
      const produtos = JSON.parse(data);

      // Aleatoriza os produtos
      embaralharArray(produtos);

      // Limita os produtos a 18
      const produtosLimitados = produtos.slice(0, 18);

      res.json(produtosLimitados); // Retorna os produtos aleatorizados e limitados
    } catch (error) {
      console.error('Erro ao processar os dados:', error);
      res.status(500).send('Erro ao processar os dados');
    }
  });
});

// Inicia o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
