function pesquisar(){
    return null
}
function carrinho(){
    return null
}
async function carregarProdutos() {
    try {
      const response = await fetch('http://localhost:3000/api/produtos');
      const produtos = await response.json();
  
      const container = document.getElementById('produtos');
      container.className = 'produto-container';
  
      produtos.forEach(produto => {
        const card = document.createElement('div');
        card.className = 'produto-card';
  
        card.innerHTML = `
          <h2>${produto.nome}</h2>
          <p>${produto.descricao}</p>
          <p>Preço: R$ ${produto.preco.toFixed(2)}</p>
          <p>Estoque: ${produto.quantidadeEstoque}</p>
        `;
        container.appendChild(card);
      });
    } catch (error) {
      console.error('Erro ao carregar os produtos:', error);
    }
  }
  carregarProdutos();  